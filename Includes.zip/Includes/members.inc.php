<?php
//checks if button clicked
if(isset($_POST['submit'])) 
{

	
	require 'dbh.inc.php';

	$mname = $_POST['membername'];
		$madd = $_POST['address'];

	$mdate = $_POST['datejoined'];
	$mcontact = $_POST['contact'];
	$memail = $_POST['email'];


//error handlers

	if(empty($mname) || empty($mdate) || empty($mcontact) || empty($memail) || empty($madd))
	{
		header("Location: ../members.php?error=emptyfields");
		
		exit();
	}

				else
				{
					$sql = "INSERT INTO members(member_name, member_address, member_date, member_contact, member_email) VALUES ('$mname', '$madd', '$mdate', '$mcontact', '$memail')";
					mysqli_query($conn, $sql);
						header("Location: ../members.php"); ///// go to home page
						exit();
					
				}

				
exit();
}