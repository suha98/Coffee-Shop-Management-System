<?php
//checks if button clicked
if(isset($_POST['submit'])) 
{

	
	require 'dbh.inc.php';

	$edate = $_POST['datejoined'];
	$ename = $_POST['employeename'];
	$edesig = $_POST['designation'];
	$egender = $_POST['gender'];
	$edob = $_POST['DOB'];
	$econtact = $_POST['contactnumber'];



//error handlers

	if(empty($edate) || empty($ename) || empty($edesig) || empty($egender) || empty($edob) || empty($econtact) )
	{
		header("Location: ../employees.php?error=emptyfields");
	
		exit();
	}
	
				else
				{
					$sql = "INSERT INTO employee(emp_date, emp_name, emp_designation, emp_gender, emp_DOB, emp_contact) VALUES ('$edate', '$ename', '$edesig', '$egender', '$edob','$econtact')";
					mysqli_query($conn, $sql);
						header("Location: ../employees.php?insertion=success!"); ///// go to home page
						exit();
					
				}
exit();
}