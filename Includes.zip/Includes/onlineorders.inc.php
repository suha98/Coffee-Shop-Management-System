<?php
//checks if button clicked
if(isset($_POST['submit'])) 
{

	
	require 'dbh.inc.php';

	$odate = $_POST['orderdate'];
	$odetails = $_POST['orderdetails'];
	$ototal = $_POST['ordertotal'];
	$ocontact = $_POST['contact'];
	$oaddress = $_POST['deliveryaddress'];

//error handlers

	if(empty($odate) || empty($odetails) || empty($ototal) || empty($ocontact) || empty($oaddress) )
	{
		header("Location: ../onlineorders.php?error=emptyfields");
	
		exit();
	}
	
				else
				{
					$sql = "INSERT INTO onlineorders(order_date, order_details, order_total, order_contact, order_address) VALUES ('$odate', '$odetails', '$ototal', '$ocontact', '$oaddress')";
					mysqli_query($conn, $sql);
						header("Location: ../onlineorders.php?insertion=success!"); ///// go to home page
						exit();
					
				}
exit();
}