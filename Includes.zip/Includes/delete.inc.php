
<?php
require 'dbh.inc.php';



mysqli_select_db($conn, 'menu');
$sql = "DELETE FROM menu WHERE item_code= '$_GET[id]'";
mysqli_query($conn, $sql);

	header("Location: ../menu.php");
					
?>
					


