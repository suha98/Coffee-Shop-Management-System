<?php
//checks if button clicked

if(isset($_POST['submit'])) 
{

	
	require 'dbh.inc.php';

	$icat = $_POST['itemcat'];
	$iname = $_POST['itemname'];
	$iserving = $_POST['itemserving'];
	$iprice = $_POST['itemprice'];
		$iupdate = $_POST['update'];



//error handlers

	if(empty($icat) || empty($iprice) || empty($iname) || empty($iserving) || empty($iupdate) )
	{
		header("Location: ../menue.php?error=emptyfields");
		
		echo '<script type = "text/javascript">';
		echo 'alert("Please fill in the empty fields.")';
		echo '</script>';
		exit();
	}
	
				else
				{
					$sql = "INSERT INTO menu(item_cat, item_name, item_serves, item_price, updated_by) VALUES ('$icat', '$iname', '$iserving', '$iprice', '$iupdate')";
					mysqli_query($conn, $sql);
						header("Location: ../menue.php?insertion=success!"); ///// go to home page
						exit();
					
				}
exit();
}