
<?php
require 'dbh.inc.php';



mysqli_select_db($conn, 'inventory');
$sql = "DELETE FROM inventory WHERE item_id= '$_GET[iid]'";
mysqli_query($conn, $sql);

	header("Location: ../inventory.php");
					
?>
					


