<?php
//checks if signup button clicked
if(isset($_POST['signup-submit'])) 
{
	require 'dbh.inc.php';
	
	$usertype = $_POST['utype'];

	$username = $_POST['uid'];
	$mail = $_POST['mail'];
	$pass = $_POST['pwd'];
	$repeatpass = $_POST['pwd-repeat'];


//error handlers

	if(empty($usertype) || empty($username) || empty($mail) || empty($pass) || empty($repeatpass) )
	{
		header("Location: ../signup.php?error=emptyfields&uid=".$username."&mail=".$mail);
		exit();
	}
	elseif (!filter_var($mail, FILTER_VALIDATE_EMAIL) && !preg_match("/^[a-zA-Z0-9]*$/", $username)) {
	header("Location: ../signup.php?error=invalidmailuid");
		exit();
	}
	//checking if valid mail
	elseif (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
		header("Location: ../signup.php?error=invalidmail&uid=".$username);
		exit();
	}

	elseif (!preg_match("/^[a-zA-Z0-9]*$/", $username)) {
		header("Location: ../signup.php?error=invaliduid&mail=".$mail);
		exit();
	}


	elseif ($pass!==$repeatpass) {
		header("Location: ../signup.php?error=passwordcheck&uid=".$username."&mail=".$mail);
		exit();
	}
	else {
			$sql = "SELECT uName FROM users WHERE uName=?";
			$stmt = mysqli_stmt_init($conn);
			if(!mysqli_stmt_prepare($stmt, $sql))
			{
				header("Location: ../signup.php?error=sqlerror");
			exit();
			}
		else {
				// checking if same username been entered multiple times
				mysqli_stmt_bind_param($stmt, "s", $username);
				mysqli_stmt_execute($stmt);
				mysqli_stmt_store_result($stmt); //fetching from database
				$result_check = mysqli_stmt_num_rows($stmt);
				
				if (result_check > 0) {
				header("Location: ../signup.php?error=usertaken&mail=".$mail);
				exit();
				}

				else
				{
					$sql = "INSERT INTO users (uType, uName, emailUsers, pwdUsers) VALUES (?, ?, ?, ?)";
					$stmt = mysqli_stmt_init($conn);
					if(!mysqli_stmt_prepare($stmt, $sql))
					{
						header("Location: ../signup.php?error=sqlerror");
						exit();

					}
					else{

						$hashedPwd = password_hash($pass, PASSWORD_DEFAULT);
						mysqli_stmt_bind_param($stmt, "ssss", $usertype, $username, $mail, $hashedPwd);
						mysqli_stmt_execute($stmt);
						header("Location: ../header.php?signup=success"); ///// go to home page
						exit();
					}
				}
			}
		}
		mysqli_stmt_close($stmt);
		mysqli_close($conn);
}

