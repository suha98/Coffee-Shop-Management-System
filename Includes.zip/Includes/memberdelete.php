

<?php
require 'dbh.inc.php';



mysqli_select_db($conn, 'members');
$sql = "DELETE FROM members WHERE member_id= '$_GET[mid]'";
mysqli_query($conn, $sql);

	header("Location: ../members.php");
					
?>
					


