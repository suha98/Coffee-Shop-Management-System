
<?php
require 'dbh.inc.php';



mysqli_select_db($conn, 'employee');
$sql = "DELETE FROM employee WHERE emp_id= '$_GET[eid]'";
mysqli_query($conn, $sql);

	header("Location: ../employees.php");
					
?>
					


