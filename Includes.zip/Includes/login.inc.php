<?php
//checks if signup button clicked
if(isset($_POST['login-submit'])) 
{
	require 'dbh.inc.php';

	$username = $_POST['uid'];
	$pass = $_POST['pwd'];

	if(empty($username) || empty($pass))
	{	
		header("Location: ../login.php?error=emptyfields&uid=".$username);
		exit();
	}
	else

	{
		$sql = "SELECT * FROM users WHERE uName=? OR emailUsers=?;";
		$stmt = mysqli_stmt_init($conn);
		if(!mysqli_stmt_prepare($stmt, $sql))
					{
						header("Location: ../login.php?error=sqlerror");
						exit();

					}

					else{

						mysqli_stmt_bind_param($stmt, "ss", $username, $username);
						mysqli_stmt_execute($stmt);
						$result = mysqli_stmt_get_result($stmt);
						if($row = mysqli_fetch_assoc($result)) //in case result empty
						{
							$pwdCheck = password_verify($pass, $row['pwdUsers']);
							if($pwdCheck == false) 
							{
								header("Location: ../login.php?error=wrongpwd");
								echo '<script language="javascript">';
								echo 'alert("Incorrect password.")';
								echo '</script>';
								exit();
							}
							elseif ($pwdCheck == true) {

								$sql = "SELECT uType FROM users WHERE uName=? OR emailUsers=?;";
								mysqli_query($conn, $sql);

		                        if ($row['uType'] == 'Admin'){
		                        	session_start();
								$_SESSION['userId'] = $row['idUsers'];
								$_SESSION['userUid'] = $row['uName'];

								header("Location: ../database.php?Success!"); //////go to home page
								exit();
		                        }

		                         elseif ($row['uType'] == 'Customer'){
		                        	session_start();
								$_SESSION['userId'] = $row['idUsers'];
								$_SESSION['userUid'] = $row['uName'];

								header("Location: ../membersview.php?Success!"); //////go to home page
								exit();
		                        }
		                        elseif ($row['uType'] == 'Employee'){
		                        	session_start();
								$_SESSION['userId'] = $row['idUsers'];
								$_SESSION['userUid'] = $row['uName'];

								header("Location: ../employeeview.php?Success!"); //////go to home page
								exit();
		                        }
								
							}
						}
						else
							{
								header("Location: ../login.php?WrongUserID");
								echo '<script language="javascript">';
								echo 'alert("Invalid Username.")';
								echo '</script>';
								exit();
							}
						exit();

					}

	}
}
else
{
header("Location: ../index.php");
		exit();
}