<?php
//checks if button clicked
if(isset($_POST['submit'])) 
{

	
	require 'dbh.inc.php';

	$rdate = $_POST['datemade'];
	$rby = $_POST['reservedby'];
	$rcustomer = $_POST['customerID'];
	$rbooked = $_POST['datebooked'];
	$rpeople = $_POST['peoplenumber'];
	$rtable = $_POST['tablenumber'];	
	$rcontact = $_POST['contactnumber'];



//error handlers

	if(empty($rdate) || empty($rby) || empty($rbooked) || empty($rcustomer)|| empty($rpeople) || empty($rtable)|| empty($rcontact))
	{
		header("Location: ../reservations.php?error=emptyfields");
	
		exit();
	}
	
				else
				{
					$sql = "INSERT INTO reservations( reserve_date, reserve_by, customer_id, date_booked, people_number, table_number, contact_number) VALUES ('$rdate', '$rby', '$rcustomer', '$rbooked', '$rpeople', '$rtable', '$rcontact')";
					mysqli_query($conn, $sql);
						header("Location: ../membersview.php?insertion=success!"); ///// go to home page
						exit();
					
				}
exit();
}