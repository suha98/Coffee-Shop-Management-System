<?
	mysqli_select_db($conn, 'onlineorders');
$sql = "DELETE FROM onlineorders WHERE order_id= '$_GET[oid]'";
mysqli_query($conn, $sql);

	header("Location: ../onlineorders.php?error=sqlerror");

?>