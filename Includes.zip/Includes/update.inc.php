<?php

require 'dbh.inc.php'

?>
<!DOCTYPE html>
<html>
<head>
<title>Tabaq Coffee</title>

  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../reservations.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #110B0D; opacity: 0.7;">
  <a class="navbar-brand" href="#" style="color: white; font-family: serif;">TABAQ COFFEE</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
         <li class="nav-item">
        <a class="nav-link" href="header.php" style="color: white; font-family: serif;">Signout</a>
      </li>
        <a class="nav-link" href="menu.php" style="color: white; font-family: serif;">Menu</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="sales.php" style="color: white; font-family: serif;">Sales</a>
      </li>

       <li class="nav-item">
        <a class="nav-link" href="reservations.php" style="color: white; font-family: serif;">Table Reservations</a>
      </li>

    </ul>
  </div>
</nav>





 




<!-- The Modal -->
<div id="addreserve_form"  style="width: 500px; height: 570px;">

  <!-- Modal content -->
  <div class="form_content">

	<h1>MAKE RESERVATION</h1> 


	<form action="includes/reservations.inc.php" method="post">

    <p>Date</p>
<input type="date" name="datemade" placeholder="Enter date" value="<?php echo $_GET['rdate']; ?>">

  <p>Reserved By</p>
  <input type="text" name="reservedby" placeholder="" value="<?php echo $_GET['rby']; ?>">
  <p>Date Booked</p>
  <input type="date" name="datebooked" placeholder="" value="<?php echo $_GET['rbooked']; ?>">
  <p>Number of People</p>
  <input type="number" name="peoplenumber" placeholder="Enter number of people" value="<?php echo $_GET['rpeople']; ?>">
  <p>Table Number</p>
  <input type="number" name="tablenumber" placeholder="Enter table number" value="<?php echo $_GET['rtable']; ?>">
  <p>Contact</p>
  <input type="number" name="contactnumber" placeholder="Enter contact number" value="<?php echo $_GET['r']; ?>">
  <input type="submit" name="submit" value="Submit" onclick="addRow('reservetable')"> <br><br>
  </form>





  </div>
</div>

<?php

//checks if button clicked
if(isset($_GET['edit'])) 
{

	$rdate = $_POST['datemade'];
	$rby = $_POST['reservedby'];
	$rbooked = $_POST['datebooked'];
	$rpeople = $_POST['peoplenumber'];
	$rtable = $_POST['tablenumber'];	
	$rcontact = $_POST['contactnumber'];

//////$sql2 = "UPDATE reservations SET reserve_date = $rdate WHERE reserve_id='$_GET[rid]'"; 
								/////////mysqli_query($conn, $sql2);

}
?>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>























