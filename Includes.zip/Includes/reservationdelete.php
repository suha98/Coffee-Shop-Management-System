
<?php
require 'dbh.inc.php';



mysqli_select_db($conn, 'reservations');
$sql = "DELETE FROM reservations WHERE reserve_id= '$_GET[rid]'";
mysqli_query($conn, $sql);

	header("Location: ../reservations.php");
					
?>
					


