<?php
//checks if button clicked
if(isset($_POST['submit'])) 
{

	
	require 'dbh.inc.php';

	$fdate = $_POST['feedbackdate'];
	$fcustomer = $_POST['feedbackcustomer'];
	$fquality = $_POST['feedbackfoodquality'];
	$fservice = $_POST['feedbackservice'];
	$fclean = $_POST['feedbackclean'];
	$fsuggestion = $_POST['feedbacksuggestions'];


//error handlers

	if(empty($fdate) || empty($fcustomer) || empty($fquality) || empty($fservice) || empty($fclean) || empty($fsuggestion) )
	{
		header("Location: ../feedback.php?error=emptyfields");
	
		exit();
	}
	
				else
				{
					$sql = "INSERT INTO feedback(feedback_date, customer_id, feedback_foodquality, feedback_service, feedback_clean, feedback_suggestions) VALUES ('$fdate', '$fcustomer', '$fquality', '$fservice', '$fclean', '$fsuggestion')";
					mysqli_query($conn, $sql);
						header("Location: ../membersview.php?insertion=success!"); ///// go to home page
						exit();
					
				}
exit();
}