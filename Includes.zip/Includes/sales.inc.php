<?php
//checks if button clicked

	if(isset($_POST['submit'])) 
{
	require 'dbh.inc.php';

	$sdate = $_POST['saledate'];
	$sitem = $_POST['saleitem'];
	$scus = $_POST['salecustomerID'];
	$sprice = $_POST['saleitemprice'];
	$squantity = $_POST['saleitemquantity'];



//error handlers

	if(empty($sdate) || empty($sitem) || empty($scus)|| empty($sprice) || empty($squantity))
	{
		header("Location: ../sales.php?error=emptyfields");
		exit();
	}
				else
				{

				
						$stotal = $sprice * $squantity;
					$sql = "INSERT INTO sales(sale_date, sale_item, ordered_by, sale_price, sale_quantity, sale_total) VALUES ('$sdate', '$sitem', '$scus', '$sprice', '$squantity', '$stotal')";
					mysqli_query($conn, $sql);
						header("Location: ../membersview.php?insertion=success!"); ///// go to home page
						exit();
					}
				}
					
			
					
					
				