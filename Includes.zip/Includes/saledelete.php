<?php
require 'dbh.inc.php';



mysqli_select_db($conn, 'sales');
$sql = "DELETE FROM sales WHERE sale_id= '$_GET[sid]'";
mysqli_query($conn, $sql);

	header("Location: ../sales.php");
					
?>
					


