<?php
//checks if button clicked
if(isset($_POST['submit'])) 
{

	
	require 'dbh.inc.php';

	$iadd= $_POST['addedby'];
		$iname = $_POST['itemname'];
	$iquan = $_POST['availablequantity'];
	$imin = $_POST['minimum'];
	$idate = $_POST['shipmentdate'];


//error handlers

	if(empty($iname) || empty($iquan) || empty($imin) || empty($idate) )
	{
		header("Location: ../inventory.php?error=emptyfields");
	
		exit();
	}
	
				else
				{
					$sql = "INSERT INTO inventory(added_by, item_name, available_quantity, minimum_required, last_shipment) VALUES ('$iadd', $iname', '$iquan', '$imin', '$idate')";
					mysqli_query($conn, $sql);
						header("Location: ../employeescreen.php?insertion=success!"); ///// go to home page
						exit();
					
				}
exit();
}