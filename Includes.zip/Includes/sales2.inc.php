<?php

if(isset($_POST['submit'])) 
{
	require 'dbh.inc.php';

	$semp = $_POST['empID'];
	$sorder = $_POST['orderID'];




//error handlers

	if(empty($semp) || empty($sorder) )
	{
		header("Location: ../sales.php?error=emptyfields");
		exit();
	}
				else
				{
						$sql2 = "UPDATE sales SET received_by= $semp WHERE sale_id = $sorder"; 
								mysqli_query($conn, $sql2);
								header("Location: ../salese.php");
					}
 }