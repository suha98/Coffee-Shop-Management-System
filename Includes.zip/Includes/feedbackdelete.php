
<?php
require 'dbh.inc.php';



mysqli_select_db($conn, 'feedback');
$sql = "DELETE FROM feedback WHERE feedback_number= '$_GET[fnum]'";
mysqli_query($conn, $sql);

	header("Location: ../feedback.php");
					
?>
					


